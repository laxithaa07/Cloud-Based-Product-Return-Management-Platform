const $ = (s) => document.querySelector(s);
const formPanel = $("#form-panel");
const returnForm = $("#return-form");
const list = $("#request-list");
const empty = $("#empty-state");
const message = $("#message");
let requests = [];

$("#open-form").addEventListener("click", () => {
  formPanel.hidden = false;
  formPanel.scrollIntoView({ behavior: "smooth", block: "start" });
  $("#order-number").focus();
});
function closeForm() {
  formPanel.hidden = true;
  returnForm.reset();
  $("#form-error").textContent = "";
}
$("#close-form").addEventListener("click", closeForm);
$("#cancel-form").addEventListener("click", closeForm);
$("#search").addEventListener("input", render);
$("#status-filter").addEventListener("change", render);

function notify(text, isError = false) {
  message.textContent = text;
  message.classList.toggle("error", isError);
  message.hidden = false;
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => { message.hidden = true; }, 4500);
}
async function api(url = "/api/returns", options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
async function load() {
  try {
    requests = await api();
    updateStats();
    render();
  } catch (error) {
    $("#result-count").textContent = "Backend unavailable";
    empty.hidden = false;
    notify("Could not connect to the Java backend. Start it using the README instructions.", true);
  }
}
returnForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  $("#form-error").textContent = "";
  const button = $("#save-button");
  button.disabled = true;
  const payload = {
    orderNumber: $("#order-number").value.trim(),
    customer: $("#customer").value.trim(),
    product: $("#product").value.trim(),
    reason: $("#reason").value,
    details: $("#details").value.trim()
  };
  try {
    await api("/api/returns", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    closeForm();
    await load();
    notify("Return request submitted.");
  } catch (error) {
    $("#form-error").textContent = error.message;
  } finally {
    button.disabled = false;
  }
});
async function updateStatus(id, status) {
  try {
    await api(`/api/returns?id=${encodeURIComponent(id)}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    await load();
    notify("Return status updated.");
  } catch (error) { notify(error.message, true); }
}
async function removeRequest(id) {
  if (!confirm("Delete this return request? This cannot be undone.")) return;
  try {
    await api(`/api/returns?id=${encodeURIComponent(id)}`, { method: "DELETE" });
    await load();
    notify("Return request deleted.");
  } catch (error) { notify(error.message, true); }
}
function updateStats() {
  $("#total-count").textContent = requests.length;
  $("#pending-count").textContent = requests.filter(r => ["Requested", "Approved"].includes(r.status)).length;
  $("#refunded-count").textContent = requests.filter(r => r.status === "Refunded").length;
}
function render() {
  const term = $("#search").value.trim().toLowerCase();
  const status = $("#status-filter").value;
  const filtered = requests.filter(r =>
    [r.id, r.orderNumber, r.customer, r.product, r.reason, r.details, r.status].join(" ").toLowerCase().includes(term)
    && (!status || r.status === status)
  );
  $("#result-count").textContent = `${filtered.length} request${filtered.length === 1 ? "" : "s"}`;
  list.replaceChildren();
  empty.hidden = filtered.length > 0;
  filtered.forEach(r => list.append(makeCard(r)));
}
function makeCard(r) {
  const card = document.createElement("article"); card.className = "request";
  const main = document.createElement("div"); main.className = "request-main";
  const top = document.createElement("div"); top.className = "request-top";
  const title = document.createElement("h3"); title.textContent = r.product;
  const id = document.createElement("span"); id.className = "request-id"; id.textContent = r.id;
  const badge = document.createElement("span"); badge.className = `badge status-${r.status.toLowerCase()}`; badge.textContent = r.status;
  top.append(title, id, badge);
  const reason = document.createElement("p"); reason.className = "reason"; reason.textContent = `Order ${r.orderNumber} · ${r.reason}`;
  const details = document.createElement("p"); details.className = "details"; details.textContent = r.details || "No additional details provided.";
  const meta = document.createElement("p"); meta.className = "meta";
  const date = new Date(r.createdAt);
  meta.textContent = `Customer: ${r.customer} · ${Number.isNaN(date.getTime()) ? "" : date.toLocaleString()}`;
  main.append(top, reason, details, meta);
  const actions = document.createElement("div"); actions.className = "request-actions";
  const select = document.createElement("select"); select.setAttribute("aria-label", `Update status for ${r.id}`);
  for (const s of ["Requested", "Approved", "Rejected", "Received", "Refunded"]) {
    const option = document.createElement("option"); option.value = s; option.textContent = s; option.selected = s === r.status; select.append(option);
  }
  select.addEventListener("change", () => updateStatus(r.id, select.value));
  const del = document.createElement("button"); del.type = "button"; del.className = "delete"; del.textContent = "Delete request";
  del.addEventListener("click", () => removeRequest(r.id));
  actions.append(select, del);
  card.append(main, actions);
  return card;
}
load();
